

const data = [
    {
        "id": "1",
        "name": "张三",
        "gender": "男",
        "age": "70",
        "department": "心血管科",
        "operatingName": "心脏搭桥手术",
        "doctorName": "李四",
        "predTime": "120",
        //"orId": "3",
        //"startTime": "8:00"
    }, {
        "id": "2",
        "name": "王二",
        "gender": "女",
        "age": "23",
        "department": "妇产科",
        "operatingName": "剖腹产手术",
        "doctorName": "王小二",
        "predTime": "100",
        //"orId": "5",
        //"startTime": "15:00"
    }
];
export default data;